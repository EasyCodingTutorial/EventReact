import React from "react";
import "./Home.css";

const Home = () => {
  return (
    <>
      <div className="Home">
        <div className="HomeContent">
          <h6>Time To Rethink</h6>
          <h5>Unleashed Potential !</h5>
          <p>
            Welcome to Easy Event Solutions! Our website is your go-to
            destination for effortless event planning and unforgettable
            experiences. <br />
            At Easy Event Solutions, we understand that organizing an event can
            be overwhelming and time-consuming. That's why we're here to
            simplify the process and make it as smooth as possible. Whether
            you're hosting a corporate conference, a gala, a wedding, or any
            other special occasion, we've got you covered.
          </p>
        </div>
      </div>
    </>
  );
};

export default Home;
