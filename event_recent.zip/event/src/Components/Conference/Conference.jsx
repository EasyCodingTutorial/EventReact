import "./Conference.css";
const Conference = () => {
  return (
    <>
      <div className="container conference">
        <div className="row justify-content-center">
          <div className="col-sm-9">
            <h6>Next Event Starts In</h6>
            <p>
              Get ready for the upcoming conference as it is just around the
              corner! The countdown has begun, and excitement is in the air.
              Mark your calendars and prepare to be part of an unforgettable
              event. Stay tuned for updates, speaker announcements, and
              registration details. The Next Conference Starts In:
            </p>
            <h6 id="ConferenceTimingClock"></h6>
          </div>
        </div>
      </div>
    </>
  );
};
// For Countdown
var CountDownDate = new Date("July 30, 2023").getTime();
// console.log(CountDownDate);

var X = setInterval(() => {
  var Now = new Date().getTime();
  var Dis = CountDownDate - Now;
  // console.log(Dis);
  var Days = Math.floor(Dis / (1000 * 60 * 60 * 24));
  var Hours = Math.floor((Dis % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var Min = Math.floor((Dis % (1000 * 60 * 60)) / (1000 * 60));
  var Sec = Math.floor((Dis % (1000 * 60)) / 1000);

  document.getElementById("ConferenceTimingClock").innerHTML =
    Days + "D- " + Hours + "H- " + Min + "M- " + Sec + "S";

  // To Prevent From This
  if (Dis < 0) {
    clearInterval(X);
    document.getElementById("ConferenceTimingClock").innerHTML =
      "SORRY THE EVENT IS  OVER";
  }
}, 1000);

export default Conference;
