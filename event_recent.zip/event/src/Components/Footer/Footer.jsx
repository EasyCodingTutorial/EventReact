import "./Footer.css";
const Footer = () => {
  return (
    <>
      <footer>
        <a href="#">&copy; Easy Coding Tutorial</a>
      </footer>
    </>
  );
};
export default Footer;
