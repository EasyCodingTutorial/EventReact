import "./Events.css";
const Events = () => {
  return (
    <>
      <div className="EventBased container">
        <div className="content">
          <h6>Our Events Are Based On</h6>
        </div>

        <div className="row">
          <div class="col-sm-3">
            <div class="box">
              <h6>Tech Innovation</h6>
              <p>
                Embrace the spirit of technology innovation at our event, where
                we explore groundbreaking ideas, emerging trends, and disruptive
                technologies. Engage with industry pioneers, attend hands-on
                workshops, and be inspired by the limitless possibilities that
                technology offers.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Entrepreneurship</h6>
              <p>
                Ignite your entrepreneurial spirit at our event, designed to
                empower aspiring business owners and startups. Gain insights
                from successful entrepreneurs, learn essential skills, and
                connect with a network of like-minded individuals who are
                passionate about creating their own path to success.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6> Digital Marketing</h6>
              <p>
                Dive into the dynamic world of digital marketing at our event,
                where we delve into the latest strategies, tactics, and tools
                for online success. Learn from industry experts, discover
                innovative marketing campaigns, and enhance your skills to
                thrive in the ever-evolving digital landscape.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6> Sustainability</h6>
              <p>
                Join us as we champion sustainability at our event, dedicated to
                addressing environmental challenges and promoting eco-conscious
                practices. Explore renewable energy solutions, sustainable
                business models, and collaborate with experts to create a
                greener future.
              </p>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-3">
            <div class="box">
              <h6>Artificial Intelligence</h6>
              <p>
                Immerse yourself in the realm of artificial intelligence at our
                event, where we delve into the latest advancements,
                applications, and ethical considerations of AI. Engage with AI
                experts, witness live demonstrations, and gain insights into how
                AI is shaping industries.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Leadership Development</h6>
              <p>
                Leadership Development Description: Elevate your leadership
                skills at our event, tailored for professionals seeking personal
                and professional growth. Learn from renowned leaders,
                participate in interactive sessions, and gain the tools and
                knowledge to lead with confidence and impact.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6> Health and Wellness</h6>
              <p>
                Prioritize your well-being at our event, focused on promoting a
                healthy and balanced lifestyle. Discover the latest trends in
                fitness, nutrition, mental health, and holistic well-being.
                Engage with wellness experts, participate in rejuvenating
                activities, and learn strategies for enhancing your overall
                wellness.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Data Science</h6>
              <p>
                Unlock the power of data science at our event, where we explore
                the latest methodologies, tools, and applications in data
                analysis and machine learning. Gain insights from data science
                experts, participate in hands-on workshops, and harness the
                potential of data-driven decision-making.
              </p>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-3">
            <div class="box">
              <h6>Design Thinking</h6>
              <p>
                Immerse yourself in the world of design thinking at our event,
                where we explore innovative approaches to problem-solving and
                creative ideation. Engage with design thinking practitioners,
                learn practical techniques, and discover how design thinking can
                drive innovation in various industries.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Financial Technology</h6>
              <p>
                Dive into the disruptive world of financial technology at our
                event, dedicated to exploring innovative solutions, trends, and
                regulations shaping the fintech industry. Learn from industry
                leaders, discover cutting-edge fintech applications, and explore
                opportunities for digital transformation in finance.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Diversity and Inclusion</h6>
              <p>
                Celebrate diversity and foster inclusion at our event, focused
                on promoting equality and creating inclusive environments.
                Engage with diversity advocates, learn best practices for
                inclusive leadership, and explore ways to build diverse teams
                and organizations.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Social Impact</h6>
              <p>
                Make a difference through social impact at our event, dedicated
                to exploring ways to address social challenges and drive
                positive change. Engage with social entrepreneurs, nonprofit
                organizations, and changemakers, and discover innovative
                approaches to create a better world.
              </p>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-3">
            <div class="box">
              <h6>Future of Work</h6>
              <p>
                Get ready for the future of work at our event, where we discuss
                the evolving landscape of work, automation, and workforce
                trends. Gain insights into upskilling and reskilling, remote and
                flexible work models, and the role of technology in shaping the
                workplace of tomorrow. Join industry leaders, thought-provoking
                speakers, and HR experts as we explore strategies for thriving
                in the ever-changing work environment.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Customer Experience</h6>
              <p>
                Delve into the realm of exceptional customer experience at our
                event, designed to help businesses create memorable interactions
                and build loyal customer relationships. Learn from CX experts,
                discover innovative strategies for personalization and
                engagement, and gain insights into leveraging technology to
                deliver seamless customer journeys.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Augmented Reality</h6>
              <p>
                Step into the world of augmented reality at our event, where we
                showcase the transformative potential of AR in various
                industries. Explore immersive AR applications, discover how AR
                is revolutionizing training and education, and learn from
                experts who are pushing the boundaries of this emerging
                technology.
              </p>
            </div>
          </div>

          <div class="col-sm-3">
            <div class="box">
              <h6>Agile Methodology</h6>
              <p>
                Embrace agility and adaptability at our event, focused on the
                principles and practices of agile methodologies. Gain insights
                into agile project management, iterative development, and
                cross-functional collaboration. Learn from agile practitioners
                and thought leaders, and discover how to enhance productivity
                and drive successful outcomes in a rapidly changing business
                landscape.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Events;
