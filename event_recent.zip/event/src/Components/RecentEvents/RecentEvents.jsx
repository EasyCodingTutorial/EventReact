import "./RecentEvents.css";
const RecentEvents = () => {
  return (
    <>
      <div className="RecentEvents container">
        <div className="content">
          <h6>
            Recent <span>Events</span>
          </h6>
        </div>

        <div className="row">
          <div className="col-sm-4">
            <div className="box">
              <img src="/recent1.jpg" className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Tech Expo 2023</h6>
              <p>
                Explore the future of technology at the Tech Expo 2023. This
                dynamic event showcases the latest innovations in AI, robotics,
                IoT, and more. Engage with industry leaders, witness live demos,
                and gain insights into emerging trends that are reshaping the
                tech landscape.
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src="/recent2.jpg" className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Tech Expo 2023</h6>
              <p>
                Explore the future of technology at the Tech Expo 2023. This
                dynamic event showcases the latest innovations in AI, robotics,
                IoT, and more. Engage with industry leaders, witness live demos,
                and gain insights into emerging trends that are reshaping the
                tech landscape.
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src="/recent3.jpg" className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Tech Expo 2023</h6>
              <p>
                Explore the future of technology at the Tech Expo 2023. This
                dynamic event showcases the latest innovations in AI, robotics,
                IoT, and more. Engage with industry leaders, witness live demos,
                and gain insights into emerging trends that are reshaping the
                tech landscape.
              </p>
            </div>
          </div>
        </div>

        {/* Second Row */}
        <div className="row">
          <div className="col-sm-4">
            <div className="box">
              <img src="/recent4.jpg" className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Tech Expo 2023</h6>
              <p>
                Explore the future of technology at the Tech Expo 2023. This
                dynamic event showcases the latest innovations in AI, robotics,
                IoT, and more. Engage with industry leaders, witness live demos,
                and gain insights into emerging trends that are reshaping the
                tech landscape.
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src="/recent5.jpg" className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Tech Expo 2023</h6>
              <p>
                Explore the future of technology at the Tech Expo 2023. This
                dynamic event showcases the latest innovations in AI, robotics,
                IoT, and more. Engage with industry leaders, witness live demos,
                and gain insights into emerging trends that are reshaping the
                tech landscape.
              </p>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="box">
              <img src="/recent6.jpg" className="img-fluid" alt="" />
            </div>
            <div className="boxContent">
              <h6>Tech Expo 2023</h6>
              <p>
                Explore the future of technology at the Tech Expo 2023. This
                dynamic event showcases the latest innovations in AI, robotics,
                IoT, and more. Engage with industry leaders, witness live demos,
                and gain insights into emerging trends that are reshaping the
                tech landscape.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default RecentEvents;
